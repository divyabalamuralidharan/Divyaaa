function Popular(){
    return(
        <header>
            <div id="popular"><h1>Popular items</h1></div>
        </header>
    )
}
export default Popular;