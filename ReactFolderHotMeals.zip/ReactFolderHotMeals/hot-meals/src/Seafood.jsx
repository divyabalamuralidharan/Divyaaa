function Seafood(){
    return(
       <header>
        <div id="seafood"><p>Search by Food</p></div>
<div className="six">
    <div id="dosa">
        <img src="image/Food Photo.png" id="do" className="hov"/>
        <h1 id="content" className="six1">Dosa</h1>
    </div>
   
    <div id="Aapppm">
        <img src="image/Food Photo (1).png" id="do" className="hov"/>
        <h1 id="content" className="six1">Aapppm</h1>
    </div>
    <div id="Puttu">
        <img src="image/Food Photo (2).png" id="do" className="hov"/>
        <h1 id="content" className="six1">Puttu</h1>
    </div>
    <div id="Idiyappam">
        <img src="image/Food Photo (3).png" id="do" className="hov"/>
        <h1 id="content" className="six1">Idiyappam</h1>
    </div>
    <div id="Pongal">
        <img src="image/Food Photo (4).png" id="do" class="hov"/>
        <h1 id="content" className="six1">Pongal</h1>
    </div>
    <div id="Veg Rice">
        <img src="image/Food Photo (5).png" id="do" className="hov"/>
        <h1 id="content" className="six1">Veg Rice</h1>
    </div>
    
</div> 
       </header>
    );
}
export default Seafood;