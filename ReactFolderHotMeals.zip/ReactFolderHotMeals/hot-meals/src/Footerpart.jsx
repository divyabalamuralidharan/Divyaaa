function Footerpart(){
    return(
        <header>
        <div id="footerpart">
         
        <div id="footerpart1">
      <div id="company">
        <p className="co">Company</p>
        <p>About Us</p>
        <p>Team</p>
        <p>Careers</p>
        <p>Blog</p>
      </div>
      <div id="help">
        <p  className="co">Help&Support</p>
        <p>Parter with us</p>
        <p>Ride with us</p>
        
      </div>
      <div id="legal">
        <p  className="co">Legal</p>
        <p>Terms&Conditions</p>
        <p>Refund&Cancellation</p>
        <p>Privary Policy</p>
        <p>Cookie Policy</p>
      </div>
      <div id="follow">
        <p>FOLLOW US</p>
        <i className="fa-brands fa-instagram"></i> 
        <i className="fa-brands fa-facebook"></i>
        <i className="fa-brands fa-twitter"></i>
        <div id="Receive"><p>Receive exclusive offers in your mailbox</p></div>
        <div className="last">
            <div className="box">
                <i className="fa-regular fa-envelope"></i>
                <input type="text" placeholder="Enter Your email"  />
             </div>
             <button id="sub">Subscribe</button>
        </div>
    </div>
    </div>
    <div id="all"> 
        <p>All rights Reserved &copy;</p> 
        <p id="made1">Made with by 💛 Divya</p>
    </div>
      
      
    
    </div>
    </header>
    );
}
export default Footerpart;