function Five2(){
    return(
        <header>
            <div className="five2">
    <div className="gulub">
        <img src="image/Rectangle 339.png" id="five1" className="cols"/>
        <h1 id="content" className="six1">Gulab Jamun</h1>
        <button id="bot1">Order Now</button>
    </div>
    <div className="Porivellanga">
        <img src="image/Rectangle 340.png" id="five1" className="cols"/>
        <h1 id="content" className="six1">Porivellangai Urundai</h1>
        <button id="bot1">Order Now</button>
    </div>
    <div className="Jangri">
        <img src="image/Rectangle 341.png" id="five1" className="cols"/>
        <h1 id="content" className="six1">Jangri</h1>
        <button id="bot1">Order Now</button>
    </div>
    <div className="lattu">
        <img src="image/Rectangle 342.png" id="five1" className="cols"/>
        <h1 id="content" className="six1">Lattu</h1>
        <button id="bot1">Order Now</button>
    </div>
    <div className="halwa">
        <img src="image/Rectangle 343.png" id="five1" className="cols"/>
        <h1 id="content" className="six1">Halwa</h1>
        <button id="bot1">Order Now</button>
    </div>
</div>
        </header>

    );
}
export default Five2;