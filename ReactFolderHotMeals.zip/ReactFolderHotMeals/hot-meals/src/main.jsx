import React from 'react'
import ReactDOM from 'react-dom/client'
import Header from './components/Header.jsx'
import Background from '../Background.jsx'
import Image_grid from '../Image-grid.jsx'
import How from '../How.jsx'
import Seafood from './Seafood.jsx'
import Popular from './Popular.jsx'
import Five from './five.jsx'
 import './index.css'
 import Five2 from './Five2.jsx'
 import Footerpart from './Footerpart.jsx'
import Jump from './Jump.jsx'
 

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
  <Header/>
    <Background/>
    <How/>
    <Image_grid/>
    <Seafood/>
    <Jump/>
    <Popular/>
  <Five/>
  <Five2/>
  <Footerpart/>
   
  </React.StrictMode>,
)
