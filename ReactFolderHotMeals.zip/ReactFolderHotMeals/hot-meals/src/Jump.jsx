function Jump(){
    return(
      <header>
        <div id="jump"> 
    <div id="picture">
        <div id="best">
            <p><strong id="best1">Best deals</strong> Crispy<br/> Diffen</p>
        </div>
        <div id="enjoy"><p>Enjoy the large size of Dosa.Complete<br/>perfert slice of Dosa.</p></div>
    </div>
    <div id="process"><button>PROCEED TO ORDER   ></button></div>
    <div id="dosa1">
        <img src="image/Image (5).png"  id="do1" className="hov"/>
    </div>
</div>
      </header>
    )
}
export default Jump;