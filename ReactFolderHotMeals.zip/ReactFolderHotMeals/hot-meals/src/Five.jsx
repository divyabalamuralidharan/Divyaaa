function Five(){
    return(
       <header>
        <div className="five">
    <div className="murukku">
        <img src="image/Rectangle 336.png" id="five1" className="cols" />
        <h1 id="content" className="six1">Murukku</h1>
        <button id="bot1">Order Now</button>
    </div>
    <div className="paniyaram">
        <img src="image/Rectangle 336 (1).png" id="five1" className="cols"/>
        <h1 id="content" className="six1">Paniyaram</h1>
        <button id="bot1">Order Now</button>
    </div>
    <div className="Seeval">
        <img src="image/Rectangle 336 (2).png" id="five1" className="cols"/>
        <h1 id="content" className="six1">Seeval Murukku</h1>
        <button id="bot1">Order Now</button>
    </div>
    <div className="mixture">
        <img src="image/Rectangle 336 (3).png" id="five1" className="cols"/>
        <h1 id="content" className="six1">Mixture</h1>
        <button id="bot1">Order Now</button>
    </div>
    <div className="veg">
        <img src="image/Rectangle 336 (4).png" id="five1" className="cols"/>
        <h1 id="content" className="six1">Veg Soup</h1>
        <button id="bot1">Order Now</button>
    </div>
    
</div>
       </header>
    );
}
export default Five;