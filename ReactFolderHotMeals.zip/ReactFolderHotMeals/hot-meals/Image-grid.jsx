function Image_grid(){
return(
<header>
<div className="image-grid">
    <div className="colss">
        <img src="image/Image (1).png" className="cols" />
        <h1 id="content">vada</h1>
        <button id="bot">30 min Delivery</button>
    </div>
    <div className="colss">
        <img src="image/Image (2).png" className="cols"/>
        <h1 id="content">Idly</h1>
        <button id="bot">30 min Delivery</button>
    </div>
    <div className="colss">
        <img src="image/Image (3).png" className="cols"/>
        <h1 id="content">parotta</h1>
        <button id="bot">30 min Delivery</button>
    </div>
    <div className="colss">
        <img src="image/Image.png"className="cols"/>
        <h1 id="content">Kichadi</h1>
        <button id="bot">30 min Delivery</button>
    </div>
</div>
</header>
);
}
export default Image_grid;