function How(){
    return(
<header>
<div id="how">
    <p id="how1">How does it work</p>

</div>
</header>
    );
}
export default How;